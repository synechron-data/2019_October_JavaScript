'use strict'

// var a = 45;
// var b = "45";

// var r1 = a == b;        // Abstract Equality
// console.log(r1);

// var r2 = a === b;        // Strict Equality
// console.log(r2);

// const s1 = "BLUE";
// const s2 = "BLUE";

// const s1 = new String("BLUE");
// const s2 = new String("BLUE");
// const s2 = s1; 

// const s1 = Symbol("BLUE");
// const s2 = Symbol("BLUE");

// console.log(s1 == s2);
// console.log(s1 === s2);

const Read = Symbol("Read");
const Write = Symbol("Write");
const ReadWrite = Symbol("ReadWrite");

function Open(mode) {
    if (mode == Read)
        console.log("File Opened in Read Mode");
    else if (mode == Write)
        console.log("File Opened in Write Mode");
    else if (mode == ReadWrite)
        console.log("File Opened in Read & Write Mode");
    else
        console.log("Wrong File Mode");
}

Open(Read);
Open(Write);
Open(ReadWrite);

Open("Read");
Open(new String("Read"));
Open(Symbol("Read"));