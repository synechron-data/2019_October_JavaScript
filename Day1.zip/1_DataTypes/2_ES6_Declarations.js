'use strict'
// let i = 10;
// let i = "ABC";

// console.log(i);

// Hositing not Supported
// i = 10;
// console.log("i is: ", i);
// let i;

// Block Scoping
// var a = 20;

// function Check() {
//     if (true) {
//         let a = 10;
//         console.log("Inside if Block, a is", a);
//     }
//     console.log("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

var i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);