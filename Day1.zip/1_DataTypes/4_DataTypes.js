'use strict'

// var language;
var language = undefined;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

language = null;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

var i = 10;
language = "JavaScript";
// language = 'JavaScript';
// language = `Java


//         Script - ${i}`;         // Template Literal
// language = String(10);
// language = new String(10);

console.log("language is :", language);
console.log("typeof language is :", typeof language);

// language = 10;
// language = 10.5;
// language = 11111111111111111111111111111111111111111111111111111111;
language = Infinity;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

language = true;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

language = Symbol('Blue');
console.log("language is :", language);
console.log("typeof language is :", typeof language);

// language = new Object();
language = {};
console.log("language is :", language);
console.log("typeof language is :", typeof language);

language = new Array();
console.log("language is :", language);
console.log("typeof language is :", typeof language);

// Binary Literal
language = 0b11;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

// Octal Literal
language = 0o11;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

// Hex Literal
language = 0x11;
console.log("language is :", language);
console.log("typeof language is :", typeof language);

language = parseInt('1010', 2);
console.log("language is :", language);
console.log("typeof language is :", typeof language);