'use strict'
// a = 20;
// console.log(a);

// function Check() {
//     a = 10;
//     console.group("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

// ---------------------------------- Not Type Safe
// var i = 10;
// var i = "ABC";

// console.log(i);

// ---------------------------------- Hoisting
// i = 10;
// console.log("i is: ", i);

// var i;

// console.log("i is: ", i);
// var i = 10;

// var i;
// console.log("i is: ", i);
// i = 10;

// ------------------------------------- Scoping

// var a = 10;

// function Check() {
//     if (true) {
//         var a = 10;
//         console.log("Inside if Block, a is", a);
//     }
//     console.log("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

var i = "Hello";
console.log("Before, i is", i);

(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);