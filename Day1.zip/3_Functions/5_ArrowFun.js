// function add1(x, y) {
//     return x + y;
// }

// var add2 = function (x, y) {
//     return x + y;
// }

// var add3 = (x, y) => {
//     return x + y;
// }

// var add4 = (x, y) => x + y;

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));

// -----------------------------------
// function getString(cb) {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     setInterval(function () {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// // Dev 2
// getString((s) => {
//     console.log(s);
// });

// ----------------------------------------

var employeeArr = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Abhijeet", city: "Pune" },
    { id: 3, name: "Pravin", city: "Mumbai" }
];

var result = [];

// --------------------------------------
// function searchLogic(item) {
//     return item.city === "Pune";
// }

// for (let i = 0; i < employeeArr.length; i++) {
//     if (searchLogic(employeeArr[i])) {
//         result.push(employeeArr[i]);
//     }
// }

// console.log(result);

// // -----------------------------------------

// function searchLogic(item) {
//     return item.city === "Pune";
// }

// var result = employeeArr.filter(searchLogic);

// console.log(result);

// -----------------------------------------

// var result = employeeArr.filter(function (item) {
//     return item.city === "Pune";
// });

// console.log(result);

// // -----------------------------------------
// var result = employeeArr.filter((item) => {
//     return item.city === "Pune";
// });

// console.log(result);

// -----------------------------------------

var result = employeeArr.filter((item) => item.city === "Pune");
console.log(result);
