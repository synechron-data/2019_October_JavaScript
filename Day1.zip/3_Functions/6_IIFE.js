// function hello() {
//     console.log("Hi World");
// }

// hello();

// Immediatly Invoked Function Expression
// (function () {
//     console.log("Hi World");
// })();

(() => {
    console.log("Hi World");
})();