// Function Declaration Syntax

function hello1() {
    console.log("Welcome to JavaScript World");
}

hello1();

// Function Expression Syntax
// const i = 10;
// console.log(i);
// console.log(typeof i);

const hello2 = function () {
    console.log("Welcome to JavaScript World");
}
// console.log(hello2);
// console.log(typeof hello2);

hello2();

// Function Constructor Syntax

const hello3 = new Function('console.log("Welcome to JavaScript World");');
hello3();

console.log(hello3);
console.log(typeof hello3);