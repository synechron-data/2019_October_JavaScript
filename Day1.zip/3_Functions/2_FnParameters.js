// function hello(name) {
//     if (isNaN(name))
//         console.log("Welcome,", name);
//     else
//         throw Error("Invalid Parameter Type...");
// }

// hello("Synechron");
// hello();
// hello("Manish", "Sharma");

// try {
//     // hello(23);
//     // hello(true);
// } catch (e) {
//     console.log(e.message);
// }

// ------------------------- Handling Less Parameters

// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// ES 2015 - Default Parameetrs
// function add(x = 0, y = 0) {
//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());
// console.log(add(2, "ABC"));

// ------------------------------------ Handling Extra Parameters
// function hello(name) {
//     console.log("Welcome,", name);
//     console.log(arguments);
// }

// ES 2015 - Rest Parameters
// function hello(name, ...args) {
//     console.log("Welcome,", name);
//     console.log(args);
// }

// hello("Abhijeet");
// hello("Abhijeet", "Gole");
// hello("Abhijeet", "Gole", "Pune");
// hello("Abhijeet", "Gole", "Pune", 411029);

function average(...numbers) {
    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length > 0)
        return sum / numbers.length;
    else
        return sum;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(average(...arr));
