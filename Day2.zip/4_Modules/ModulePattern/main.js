var r = dev1.square(10);
console.log(r);

dev2.Check();
console.log(dev2.square);