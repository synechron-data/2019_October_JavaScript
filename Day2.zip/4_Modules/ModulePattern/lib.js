var dev1;

(function (ns) {
    function square(x) {
        return x * x;
    }

    ns.square = square;
})(dev1 = dev1 || {});