var dev2;

(function (ns) {
    function Check() {
        console.log("Check Called...");
    }

    var square = 10;

    ns.Check = Check;
    ns.square = square;
})(dev2 = dev2 || {});