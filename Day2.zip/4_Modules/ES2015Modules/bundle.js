(function () {
    'use strict';

    // export default function square(x) {
    //     return x * x;
    // }

    // export default function square(x) {
    //     return x * x;
    // }

    // export function check(x) {
    //     return 'Checked...';
    // }

    function square(x) {
        return x * x;
    }

    function check(x) {
        return 'Checked...';
    }

    // import square from './lib';
    console.log("Result: ", square(20));
    console.log("Check: ", check());

}());
