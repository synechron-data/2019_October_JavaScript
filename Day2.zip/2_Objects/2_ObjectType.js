// var toy1 = new Object();
// console.log(toy1.toString());
// console.log(Object.prototype);
// console.log(String.prototype);

// var s = new String("hello");
// console.log(s);

var toy1 = new Object();
// toy1.color = "red";
Object.prototype.color = "red";

var toy2 = new Object();


console.log(toy1);
console.log(toy2);