// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// // let newSource = source;
// // let newSource = Object.assign({}, source);  // Shallow Copy

// let newSource = JSON.parse(JSON.stringify(source));

// console.log(source);
// console.log(newSource);

// newSource.id = 10;
// newSource.address.city = "Mumbai";

// console.log(source);
// console.log(newSource);

// ----------------------------------------------- Object.create
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// //  Creates a new object, using an existing object as the prototype of the newly created object.

// let newSource1 = Object.assign({}, source);
// let newSource2 = Object.create(source);

// console.log(newSource1);
// console.log(newSource2);

// ------------------------------------------- Stop Manipulation & Extension

let source = { id: 1, name: "Manish" };

Object.freeze(source);

if (!Object.isFrozen(source))
    source.id = 100;

Object.preventExtensions(source);

if (Object.isExtensible(source))
    source.city = "Pune";

console.log(source);