class BankAccount {
    constructor(accName) {
        this._accName = accName;
    }

    static set BankName(value) {
        BankAccount._bankName = value;
    }

    get BankName() {
        return BankAccount._bankName;
    }

    get AccountName() {
        return this._accName;
    }
}

BankAccount.BankName = "HDFC";

var a1 = new BankAccount("Manish");
console.log(a1.BankName);
console.log(a1.AccountName);

var a2 = new BankAccount("Abhijeet");
console.log(a2.BankName);
console.log(a2.AccountName);