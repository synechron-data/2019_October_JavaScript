'use strict'
// function Check() {
//     console.log(this);
// }

// Check();

// (function () {
//     function Check() {
//         console.log(this);
//     }

//     Check();
// })();

// var person = {
//     id: 1,
//     display: function () {
//         console.log(this);
//     }
// };

// person.display();

// setTimeout(function(){
//     person.display();
// }, 2000);

// setTimeout(person.display.bind(person), 4000);

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(this);
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(this);
//     }
// };

var p1 = {
    id: 1,
    name: "Manish"
};

var p2 = {
    id: 2,
    name: "Abhijeet"
};

function display(x, y) {
    console.log(this);
    console.log(x, y);
}

// display(23, 45);

display.call(p1, 2, 3);
display.call(p2, 2, 3);
// p1.display();
// p2.display();

display.apply(p1, [2, 3]);
display.apply(p2, [2, 3]);