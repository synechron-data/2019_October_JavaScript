'use strict'
// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// count = "Abc";
// console.log(next());

// ----------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());

// ----------------------------------

// const next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());

// -----------------------------------

// const counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.prev());

// ---------------------------------

function getCounter(interval) {
    var count = 0;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
};

var cnt1 = getCounter(1);
console.log(cnt1.next());
console.log(cnt1.prev());

console.log("\n")
var cnt10 = getCounter(10);
console.log(cnt10.next());
console.log(cnt10.prev());
