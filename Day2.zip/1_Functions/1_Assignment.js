'use strict'

// function Reverse(strOrarr) {
//     if (typeof strOrarr === "string")
//         return strOrarr.split("").reverse();
//     if (Object.prototype.toString.call(strOrarr) === "[object Array]")
//         return strOrarr.slice().reverse();
//     else
//         throw Error("Invalid Parameter Type...");
// }

function Reverse(strOrarr) {
    if (typeof strOrarr === "string")
        return strOrarr.split("").reverse();
    if (Array.isArray(strOrarr))
        return [...strOrarr].reverse();
    else
        throw Error("Invalid Parameter Type...");
}

console.log(Reverse("Manish"));
console.log(Reverse(["PQR", "XYZ", "ABC"]));
console.log(Reverse([10, 20, 30]));

// console.log(Reverse(10));
