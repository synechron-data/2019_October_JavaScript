// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' INR', 69, 0, 100));
// console.log(Converter(' INR', 69, 0, 500));
// console.log(Converter(' INR', 69, 0, 1000));
// console.log(Converter(' INR', 69, 0, 10000));

// -------------------------------------------- To be Curried
// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// const DollarToINR = Converter(' INR', 69, 0);
// console.log(DollarToINR(100));
// console.log(DollarToINR(500));
// console.log(DollarToINR(1000));
// console.log(DollarToINR(10000));

// const MilesToKm = Converter(' Km', 1.6, 0);
// console.log(MilesToKm(100));
// console.log(MilesToKm(500));
// console.log(MilesToKm(1000));
// console.log(MilesToKm(10000));

// --------------------------------------------Currying using bind

function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

// var mGreet = greetings.bind(this, "Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

const DollarToINR = Converter.bind(this, ' INR', 69, 0);
console.log(DollarToINR(100));
console.log(DollarToINR(500));
console.log(DollarToINR(1000));
console.log(DollarToINR(10000));