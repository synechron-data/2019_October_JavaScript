class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];            
    //     }
    // }

    // [Symbol.iterator]() {
    //     var self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     }
    // }
}

var orderQueue = new Queue();

orderQueue.push("Order 1");
orderQueue.push("Order 2");
orderQueue.push("Order 4");
orderQueue.push("Order 3");
orderQueue.push("Order 5");

for (const order of orderQueue) {
    console.log(order);
}

// console.log(orderQueue.pop());
// console.log(orderQueue.pop());
// console.log(orderQueue.pop());
// console.log(orderQueue.pop());
// console.log(orderQueue.pop());