var map = new Map();
var wmap = new WeakMap();

(function () {
    var a = { a: 1 };
    var b = { b: 2 };

    map.set(a, "This is Map object");
    wmap.set(b, "This is WeakMap object");
})();

// var a = { a: 1 };
// var b = { b: 2 };

// wmap.set(a, "This is a object");
// wmap.set(b, "This is b object");

// Weak Map is not iterable
// for (const pair of wmap) {
//     console.log(pair);
// }