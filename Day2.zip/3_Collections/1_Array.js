// var employees = [];
// var employees = new Array();
// var employees = new Array(2);
// employees[0] = "Manish";
// employees[1] = "Abhijeet";
// employees[6] = "Ramakant";

// var employees = new Array(10, 20, 30, 40);

// console.log(employees);
// console.log(employees.length);

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

// for (let i = 0; i < employees.length; i++) {
//     console.log(employees[i].name);
// }

// for (const key in employees) {
//     console.log(employees[key].name);
// }

// ES 2015 - For of Loop

for (const item of employees) {
    console.log(item.name);
}